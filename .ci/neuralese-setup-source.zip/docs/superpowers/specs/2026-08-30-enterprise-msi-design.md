# Neuralese Enterprise MSI Design

## Goal

Provide a real Windows Installer package for school administrators deploying
Neuralese through Group Policy, Intune, SCCM, or an equivalent device-management
system. The existing interactive EXE installer remains available for individual
users.

## Package Model

- Build the MSI with WiX Toolset v4 on a Windows CI runner.
- Embed the complete Neuralese payload so installation has no network dependency.
- Install per-machine under `ProgramFiles64Folder\Neuralese`.
- Register Neuralese in Windows Apps and Features.
- Create machine-wide Start Menu and Public Desktop shortcuts.
- Support unattended install, repair, upgrade, and uninstall through `msiexec`.
- Use a stable `UpgradeCode` and a version-specific `ProductCode`.
- Reject downgrades and upgrade older MSI versions in place.

## Managed Update Policy

The MSI edition is managed by the school administrator. Neuralese's interactive
auto-updater must not replace files installed by Windows Installer. The package
therefore writes a machine-wide managed-install marker. The application/updater
can use that marker as the single source of truth for disabling self-update.

The consumer EXE installer does not write this marker and retains its existing
update behaviour.

## Build Inputs and Outputs

Input:

- the same `game.zip` produced by the existing Windows export workflow;
- semantic MSI version in Windows Installer's numeric version format;
- existing Neuralese icon and executable name.

Output:

- `Neuralese-<version>-x64.msi`;
- build metadata containing source commit, installer commit, version, and SHA-256;
- the existing `Neuralese-Setup.exe`, unchanged.

## Installation Contract

Supported commands include:

```powershell
msiexec /i Neuralese-<version>-x64.msi /qn /norestart
msiexec /i Neuralese-<version>-x64.msi /qn /norestart CREATE_DESKTOP_SHORTCUT=0
msiexec /x Neuralese-<version>-x64.msi /qn /norestart
```

The desktop shortcut is enabled by default and can be disabled by an
administrator property. The Start Menu shortcut is always installed.

## Reliability and Security

- Installation requires elevation and never writes application files to a user
  profile.
- All application files are owned and repaired by Windows Installer.
- Components use deterministic identifiers so repair and upgrades remain stable.
- Custom actions are avoided unless Windows Installer cannot express the required
  behaviour natively.
- No secrets or enrollment credentials are embedded in the MSI.
- A failed install or upgrade must roll back to the previous working state.
- Uninstall removes MSI-owned files and shortcuts but does not delete user-created
  projects or profile data.

## Verification

Windows CI builds and validates both installers. The MSI job must:

1. build an MSI from a fixture payload;
2. install it silently with verbose MSI logging;
3. verify the executable, managed-install marker, Start Menu shortcut, and desktop
   shortcut;
4. launch a fixture executable to prove the installed payload is runnable;
5. repair the installation and verify the files again;
6. upgrade from an older test version to a newer one without leaving duplicate
   products;
7. uninstall silently and verify MSI-owned files and shortcuts are gone;
8. upload the MSI and verification logs as CI artifacts.

The release workflow repeats the installation smoke test against the real
Neuralese payload before publishing the MSI.

## Non-goals

- Replacing the consumer EXE installer.
- Building an MSI that merely launches the EXE installer.
- Installing or configuring school enrollment secrets.
- Managing student projects or application profile data.
