# Neuralese Enterprise MSI Implementation Plan

> **Goal:** Build and verify a machine-wide, offline Neuralese MSI for school-managed Windows deployments while preserving the consumer EXE installer.

## Task 1: Establish the MSI source and deterministic payload generation

**Files:**
- Create: `packaging/msi/Neuralese.Managed.wixproj`
- Create: `packaging/msi/Package.wxs`
- Create: `packaging/msi/generate-payload.ps1`
- Create: `tests/windows/msi-source-tests.ps1`

1. Add failing source tests for stable upgrade identity, per-machine scope, downgrade prevention, no custom actions, managed marker, and shortcut properties.
2. Add a WiX SDK project pinned to a reviewed WiX v4 release.
3. Author the base package, installation directories, upgrade policy, ARP metadata, and shortcut component.
4. Generate one deterministic WiX component per payload file from its normalized relative path.
5. Reject unsafe payload paths, duplicate paths, missing `Neuralese.exe`, and invalid MSI versions.
6. Run the source tests locally where possible.

## Task 2: Add the reproducible MSI build entrypoint

**Files:**
- Create: `build-msi.ps1`
- Modify: `.gitignore`
- Modify: `README.md`
- Test: `tests/windows/msi-source-tests.ps1`

1. Add failing tests for parameter validation and expected output naming.
2. Extract `game.zip` into an isolated staging directory.
3. Add `.neuralese-managed-install` and build metadata to the staged payload.
4. Generate WiX source and run `dotnet build` with explicit version and bind paths.
5. Copy the final package to `release/Neuralese-<version>-x64.msi` and emit SHA-256 metadata.
6. Document GPO/Intune/SCCM install, repair, and uninstall commands.

## Task 3: Disable self-update only for managed installations

**Repository:** `hex358/neuralese-builder`

**Files:**
- Modify: `scripts/update_state.gd`
- Modify: `tests/godot/test_update_flow.gd` or add a focused managed-install test

1. Add a failing test proving a managed-install marker suppresses the update prompt/download flow.
2. Resolve the marker next to the running executable instead of in user data.
3. Keep existing behavior unchanged when the marker is absent.
4. Run the focused updater tests in an isolated worktree.

## Task 4: Add real Windows Installer lifecycle smoke tests

**Files:**
- Create: `tests/windows/msi-smoke.ps1`
- Create: `tests/windows/fixtures/managed-app.ps1`
- Modify: `.github/workflows/ci.yml`

1. Build two tiny fixture payloads with different versions.
2. Build version 1 MSI and install silently with verbose logging.
3. Verify Program Files payload, marker, Start Menu shortcut, desktop shortcut, ARP registration, and runnable fixture.
4. Run Windows Installer repair and verify a deleted owned file returns.
5. Build version 2 MSI and verify major upgrade replaces version 1 without duplicate ARP entries.
6. Uninstall silently and verify MSI-owned resources are removed while a simulated user-data file remains.
7. Upload the MSIs and verbose logs on success or failure.

## Task 5: Integrate MSI into the Neuralese Windows release workflow

**Repository:** `hex358/neuralese-builder`

**Files:**
- Modify: relevant branch/release Windows workflow under `.github/workflows/`
- Modify: release metadata tooling only if required to expose the MSI artifact

1. Pin the installer repository commit exactly as the existing EXE release does.
2. Build the MSI from the already verified `game.zip`; do not rebuild the app separately.
3. Run the real-payload MSI smoke test before publishing.
4. Upload `Neuralese-<version>-x64.msi`, checksum, and build metadata alongside the EXE.
5. Keep the public website's consumer download on the EXE unless a separate admin-download link is explicitly added later.

## Task 6: Final verification and delivery

1. Run installer Rust formatting, lint, unit tests, updater smoke test, and MSI source tests.
2. Push the dedicated branches only when local checks are clean.
3. Run Windows CI and inspect the MSI install/repair/upgrade/uninstall logs.
4. Download the exact CI-built MSI, verify SHA-256, and place it in the local release directory.
5. Report the MSI path, checksum, CI run, silent deployment commands, and any remaining signing limitation.
