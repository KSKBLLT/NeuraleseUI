param(
    [Parameter(Mandatory = $true)]
    [string]$PayloadZip,

    [string]$GameExeName = "Neuralese.exe",

    [Parameter(Mandatory = $true)]
    [string]$AppVersion,

    [string]$OutputDir = ".\release"
)

$ErrorActionPreference = "Stop"
$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$markerValue = "NEURALESE_MANAGED_INSTALL_V1"

function Require-Command([string]$Name, [string]$Hint) {
    if (-not (Get-Command $Name -ErrorAction SilentlyContinue)) {
        throw "Missing command '$Name'. $Hint"
    }
}

function Assert-MsiVersion([string]$Version) {
    if ($Version -notmatch '^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$') {
        throw "MSI version must use numeric major.minor.build format: $Version"
    }
    $parts = @($Version.Split('.') | ForEach-Object { [int]$_ })
    if ($parts[0] -gt 255 -or $parts[1] -gt 255 -or $parts[2] -gt 65535) {
        throw "MSI version exceeds Windows Installer limits: $Version"
    }
}

function Assert-SafeZip([string]$ZipPath) {
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $archive = [System.IO.Compression.ZipFile]::OpenRead($ZipPath)
    try {
        foreach ($entry in $archive.Entries) {
            $name = $entry.FullName.Replace("\", "/")
            if (
                [string]::IsNullOrWhiteSpace($name) -or
                $name.StartsWith("/") -or
                $name -match '^[A-Za-z]:' -or
                @($name.Split('/')) -contains '..'
            ) {
                throw "Unsafe payload path in zip: $($entry.FullName)"
            }
        }
    }
    finally {
        $archive.Dispose()
    }
}

Assert-MsiVersion $AppVersion
Require-Command "dotnet" "Install the .NET 6 SDK or newer."

$payloadZipFull = (Resolve-Path -LiteralPath $PayloadZip).Path
$outputDirFull = if ([System.IO.Path]::IsPathRooted($OutputDir)) {
    [System.IO.Path]::GetFullPath($OutputDir)
}
else {
    [System.IO.Path]::GetFullPath((Join-Path $projectRoot $OutputDir))
}

Assert-SafeZip $payloadZipFull

$stageRoot = Join-Path ([System.IO.Path]::GetTempPath()) "n\$([Guid]::NewGuid().ToString('N').Substring(0, 8))"
$payloadDir = Join-Path $stageRoot "p"
$generatedSource = Join-Path $stageRoot "Payload.generated.wxs"
$packageSource = Join-Path $projectRoot "packaging\msi\Package.wxs"
$generator = Join-Path $projectRoot "packaging\msi\generate-payload.ps1"
$toolManifest = Join-Path $projectRoot ".config\dotnet-tools.json"

try {
    New-Item -ItemType Directory -Path $payloadDir -Force | Out-Null
    [System.IO.Compression.ZipFile]::ExtractToDirectory($payloadZipFull, $payloadDir, $true)

    $executables = @(Get-ChildItem -LiteralPath $payloadDir -File -Recurse | Where-Object { $_.Name -ieq $GameExeName })
    if ($executables.Count -ne 1) {
        throw "Payload must contain exactly one '$GameExeName'; found $($executables.Count)"
    }

    [System.IO.File]::WriteAllText(
        (Join-Path $payloadDir ".neuralese-managed-install"),
        $markerValue,
        [System.Text.UTF8Encoding]::new($false)
    )
    $metadata = [ordered]@{
        schema_version = 1
        product = "Neuralese"
        version = $AppVersion
        managed_install = $true
        auto_update = $false
        payload_sha256 = (Get-FileHash -LiteralPath $payloadZipFull -Algorithm SHA256).Hash.ToLowerInvariant()
    }
    [System.IO.File]::WriteAllText(
        (Join-Path $payloadDir ".neuralese-managed-install.json"),
        ($metadata | ConvertTo-Json -Depth 4),
        [System.Text.UTF8Encoding]::new($false)
    )

    & $generator -PayloadDir $payloadDir -GameExeName $GameExeName -OutputPath $generatedSource

    & dotnet tool restore --tool-manifest $toolManifest
    if ($LASTEXITCODE -ne 0) {
        throw "WiX tool restore failed with exit code $LASTEXITCODE"
    }

    New-Item -ItemType Directory -Path $outputDirFull -Force | Out-Null
    $outputPath = Join-Path $outputDirFull "Neuralese-$AppVersion-x64.msi"
    Push-Location $projectRoot
    try {
        & dotnet tool run wix -- build $packageSource $generatedSource -arch x64 -d "ProductVersion=$AppVersion" -o $outputPath
        if ($LASTEXITCODE -ne 0) {
            throw "WiX MSI build failed with exit code $LASTEXITCODE"
        }
    }
    finally {
        Pop-Location
    }
    if (-not (Test-Path -LiteralPath $outputPath -PathType Leaf)) {
        throw "WiX reported success but MSI was not created: $outputPath"
    }

    $sha = (Get-FileHash -LiteralPath $outputPath -Algorithm SHA256).Hash.ToLowerInvariant()
    $artifactMetadata = [ordered]@{
        schema_version = 1
        artifact = [System.IO.Path]::GetFileName($outputPath)
        version = $AppVersion
        sha256 = $sha
        payload_sha256 = $metadata.payload_sha256
        installer_type = "msi"
        install_scope = "per_machine"
        auto_update = $false
    }
    $metadataPath = "$outputPath.json"
    [System.IO.File]::WriteAllText(
        $metadataPath,
        ($artifactMetadata | ConvertTo-Json -Depth 4),
        [System.Text.UTF8Encoding]::new($false)
    )

    Write-Host "Built managed MSI: $outputPath" -ForegroundColor Green
    Write-Host "SHA-256: $sha" -ForegroundColor Green
}
finally {
    Remove-Item -LiteralPath $stageRoot -Recurse -Force -ErrorAction SilentlyContinue
}
