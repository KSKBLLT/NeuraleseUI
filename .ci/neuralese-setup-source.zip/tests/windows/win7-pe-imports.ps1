param(
    [Parameter(Mandatory = $true)]
    [string]$Executable
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$Executable = (Resolve-Path -LiteralPath $Executable).Path
$vswhere = Join-Path ${env:ProgramFiles(x86)} "Microsoft Visual Studio\Installer\vswhere.exe"
if (-not (Test-Path -LiteralPath $vswhere -PathType Leaf)) {
    throw "vswhere.exe is required to locate dumpbin.exe"
}

$visualStudio = & $vswhere -latest -products * `
    -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 `
    -property installationPath
if (-not $visualStudio) {
    throw "Visual Studio C++ tools are required to inspect PE imports"
}

$dumpbin = Get-ChildItem -LiteralPath (Join-Path $visualStudio "VC\Tools\MSVC") -Directory |
    Sort-Object Name -Descending |
    ForEach-Object { Join-Path $_.FullName "bin\Hostx64\x64\dumpbin.exe" } |
    Where-Object { Test-Path -LiteralPath $_ -PathType Leaf } |
    Select-Object -First 1
if (-not $dumpbin) {
    throw "dumpbin.exe was not found in the Visual Studio installation"
}

$imports = (& $dumpbin /nologo /dependents $Executable 2>&1 | Out-String).ToLowerInvariant()
if ($LASTEXITCODE -ne 0) {
    throw "dumpbin failed while inspecting $Executable`n$imports"
}

$forbiddenImports = @(
    "api-ms-win-core-winrt-error-l1-1-0.dll",
    "api-ms-win-core-synch-l1-2-0.dll",
    "bcryptprimitives.dll",
    "vcruntime140.dll",
    "api-ms-win-crt-"
)

$found = @($forbiddenImports | Where-Object { $imports.Contains($_) })
if ($found.Count -gt 0) {
    throw "Windows 7-incompatible imports found in $Executable`: $($found -join ', ')"
}

Write-Host "PASS win7-pe-imports: no forbidden Windows 8+/dynamic CRT imports"
