$ErrorActionPreference = "Stop"

if (-not $env:RUNNER_TEMP) {
    $env:RUNNER_TEMP = [System.IO.Path]::GetTempPath()
}

$repo = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
$buildScript = Join-Path $repo "build-msi.ps1"
$installRoot = Join-Path $env:ProgramFiles "Neuralese"
$desktopShortcut = Join-Path $env:PUBLIC "Desktop\Neuralese.lnk"
$startMenuShortcut = Join-Path $env:ProgramData "Microsoft\Windows\Start Menu\Programs\Neuralese.lnk"
$userDataRoot = Join-Path $env:ProgramData "Neuralese\UserData"
$userDataSentinel = Join-Path $userDataRoot "keep.txt"
$temp = Join-Path $env:RUNNER_TEMP "neuralese-msi-smoke-$([Guid]::NewGuid().ToString('N'))"
$logs = Join-Path $temp "logs"
$savedLogs = Join-Path $repo "test-results\msi"

function Invoke-MsiExec([string[]]$Arguments, [string]$Name) {
    $process = Start-Process -FilePath "$env:SystemRoot\System32\msiexec.exe" -ArgumentList $Arguments -Wait -PassThru
    if ($process.ExitCode -notin @(0, 3010)) {
        throw "$Name failed with Windows Installer exit code $($process.ExitCode)"
    }
}

function Assert-Exists([string]$Path, [string]$Description) {
    if (-not (Test-Path -LiteralPath $Path)) {
        throw "$Description is missing: $Path"
    }
}

function Assert-NotExists([string]$Path, [string]$Description) {
    if (Test-Path -LiteralPath $Path) {
        throw "$Description still exists: $Path"
    }
}

function New-FixturePayload([string]$Version, [string]$Destination) {
    $source = Join-Path $temp "payload-$Version"
    New-Item -ItemType Directory -Path (Join-Path $source "runtime") -Force | Out-Null
    Copy-Item -LiteralPath "$env:SystemRoot\System32\whoami.exe" -Destination (Join-Path $source "Neuralese.exe")
    Set-Content -LiteralPath (Join-Path $source "payload-version.txt") -Value $Version -Encoding ascii
    Set-Content -LiteralPath (Join-Path $source "runtime\data.txt") -Value "repair-$Version" -Encoding ascii
    Compress-Archive -Path (Join-Path $source "*") -DestinationPath $Destination -Force
}

function Find-ManagedArpEntries() {
    $roots = @(
        "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall",
        "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"
    )
    $entries = @()
    foreach ($root in $roots) {
        if (-not (Test-Path -LiteralPath $root)) { continue }
        foreach ($key in Get-ChildItem -LiteralPath $root) {
            $item = Get-ItemProperty -LiteralPath $key.PSPath
            if ($item.DisplayName -eq "Neuralese (Managed)") {
                $entries += $item
            }
        }
    }
    return @($entries)
}

if ((Find-ManagedArpEntries).Count -ne 0 -or (Test-Path -LiteralPath $installRoot)) {
    throw "Refusing to run MSI smoke test over an existing Neuralese managed installation"
}

try {
    New-Item -ItemType Directory -Path $logs, $userDataRoot -Force | Out-Null
    Set-Content -LiteralPath $userDataSentinel -Value "student-data-must-survive" -Encoding ascii

    $zipV1 = Join-Path $temp "payload-9.8.1.zip"
    $zipV2 = Join-Path $temp "payload-9.8.2.zip"
    $buildV1 = Join-Path $temp "build-v1"
    $buildV2 = Join-Path $temp "build-v2"
    New-FixturePayload "9.8.1" $zipV1
    New-FixturePayload "9.8.2" $zipV2

    Push-Location $temp
    try {
        & $buildScript -PayloadZip $zipV1 -AppVersion "9.8.1" -OutputDir $buildV1
        & $buildScript -PayloadZip $zipV2 -AppVersion "9.8.2" -OutputDir $buildV2
    }
    finally {
        Pop-Location
    }
    $msiV1 = Join-Path $buildV1 "Neuralese-9.8.1-x64.msi"
    $msiV2 = Join-Path $buildV2 "Neuralese-9.8.2-x64.msi"
    Assert-Exists $msiV1 "MSI v1"
    Assert-Exists $msiV2 "MSI v2"

    Invoke-MsiExec @("/i", $msiV1, "/qn", "/norestart", "/l*v", (Join-Path $logs "install-v1.log")) "Silent install"
    $installedExe = Join-Path $installRoot "Neuralese.exe"
    $managedMarker = Join-Path $installRoot ".neuralese-managed-install"
    $repairTarget = Join-Path $installRoot "runtime\data.txt"
    Assert-Exists $installedExe "Installed executable"
    Assert-Exists $managedMarker "Managed install marker"
    Assert-Exists $desktopShortcut "Common desktop shortcut"
    Assert-Exists $startMenuShortcut "Common Start Menu shortcut"
    if ((Get-Content -LiteralPath $managedMarker -Raw).Trim() -ne "NEURALESE_MANAGED_INSTALL_V1") {
        throw "Managed install marker has an unexpected value"
    }
    $launch = Start-Process -FilePath $installedExe -ArgumentList "/user" -Wait -PassThru -WindowStyle Hidden
    if ($launch.ExitCode -ne 0) { throw "Installed fixture executable did not launch successfully" }

    Remove-Item -LiteralPath $repairTarget -Force
    Invoke-MsiExec @("/fa", $msiV1, "/qn", "/norestart", "/l*v", (Join-Path $logs "repair-v1.log")) "Silent repair"
    Assert-Exists $repairTarget "Repaired payload file"

    Invoke-MsiExec @("/i", $msiV2, "/qn", "/norestart", "/l*v", (Join-Path $logs "upgrade-v2.log")) "Major upgrade"
    if ((Get-Content -LiteralPath (Join-Path $installRoot "payload-version.txt") -Raw).Trim() -ne "9.8.2") {
        throw "Major upgrade did not replace the payload"
    }
    $arpEntries = @(Find-ManagedArpEntries)
    if ($arpEntries.Count -ne 1 -or $arpEntries[0].DisplayVersion -ne "9.8.2") {
        throw "Expected one managed ARP entry at version 9.8.2; found $($arpEntries.Count)"
    }

    Invoke-MsiExec @("/x", $msiV2, "/qn", "/norestart", "/l*v", (Join-Path $logs "uninstall-v2.log")) "Silent uninstall"
    Assert-NotExists $installRoot "Managed install root"
    Assert-NotExists $desktopShortcut "Common desktop shortcut"
    Assert-NotExists $startMenuShortcut "Common Start Menu shortcut"
    Assert-Exists $userDataSentinel "External user data sentinel"
    if ((Find-ManagedArpEntries).Count -ne 0) {
        throw "Managed ARP entry remained after uninstall"
    }

    Write-Host "PASS msi-smoke"
}
finally {
    $remaining = @(Find-ManagedArpEntries)
    foreach ($entry in $remaining) {
        if ($entry.PSChildName -match '^\{[0-9A-Fa-f-]+\}$') {
            Start-Process -FilePath "$env:SystemRoot\System32\msiexec.exe" -ArgumentList @("/x", $entry.PSChildName, "/qn", "/norestart") -Wait | Out-Null
        }
    }
    Remove-Item -LiteralPath $installRoot -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $desktopShortcut -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $startMenuShortcut -Force -ErrorAction SilentlyContinue
    if (Test-Path -LiteralPath $logs) {
        New-Item -ItemType Directory -Path $savedLogs -Force | Out-Null
        Copy-Item -Path (Join-Path $logs "*") -Destination $savedLogs -Force -ErrorAction SilentlyContinue
    }
    Remove-Item -LiteralPath (Split-Path -Parent $userDataRoot) -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $temp -Recurse -Force -ErrorAction SilentlyContinue
}
