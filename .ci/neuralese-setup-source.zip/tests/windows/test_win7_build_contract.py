import pathlib
import unittest


ROOT = pathlib.Path(__file__).resolve().parents[2]
WINDOWS_7_TARGET = "x86_64-win7-windows-msvc"


class Windows7BuildContractTests(unittest.TestCase):
    def test_slint_does_not_link_windows_accessibility_runtime(self):
        cargo_toml = (ROOT / "src-tauri" / "Cargo.toml").read_text(encoding="utf-8")

        self.assertNotIn('"accessibility"', cargo_toml)

    def test_release_build_uses_windows_7_target_and_static_crt(self):
        build_script = (ROOT / "build.ps1").read_text(encoding="utf-8")

        self.assertIn(WINDOWS_7_TARGET, build_script)
        self.assertIn("target-feature=+crt-static", build_script)
        self.assertIn("windows_slim_errors", build_script)
        self.assertIn("-Z build-std=std,panic_abort", build_script)
        self.assertIn("windows_x86_64_msvc-0.48.5", build_script)

    def test_ci_builds_and_checks_windows_7_executable_imports(self):
        workflow = (ROOT / ".github" / "workflows" / "ci.yml").read_text(
            encoding="utf-8"
        )

        self.assertIn(WINDOWS_7_TARGET, workflow)
        self.assertIn("rust-src", workflow)
        self.assertIn("win7-pe-imports.ps1", workflow)
        self.assertIn(".\\build.ps1", workflow)
        self.assertIn("fail-fast: false", workflow)
        self.assertIn("Swatinem/rust-cache@6323deb102c322ba6fcbdcafc7e3dddab59af2b6", workflow)
        self.assertIn("if: always()", workflow)


if __name__ == "__main__":
    unittest.main()
