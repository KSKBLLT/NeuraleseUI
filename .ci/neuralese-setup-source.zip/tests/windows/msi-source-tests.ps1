$ErrorActionPreference = "Stop"

$repo = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
$package = Join-Path $repo "packaging\msi\Package.wxs"
$generator = Join-Path $repo "packaging\msi\generate-payload.ps1"
$buildScript = Join-Path $repo "build-msi.ps1"

foreach ($required in @($package, $generator, $buildScript)) {
    if (-not (Test-Path -LiteralPath $required -PathType Leaf)) {
        throw "Required MSI source is missing: $required"
    }
}

$packageText = Get-Content -LiteralPath $package -Raw
$requiredPatterns = @(
    'Scope="perMachine"',
    'UpgradeCode="{',
    '<MajorUpgrade',
    'DowngradeErrorMessage=',
    'ProgramFiles64Folder',
    'CREATE_DESKTOP_SHORTCUT',
    'DesktopShortcutComponent',
    'StartMenuShortcutComponent',
    'PayloadComponents'
)
foreach ($pattern in $requiredPatterns) {
    if (-not $packageText.Contains($pattern)) {
        throw "Package.wxs is missing required authoring: $pattern"
    }
}
if ($packageText -match '<CustomAction\b') {
    throw "Enterprise MSI must not contain custom actions"
}

$buildScriptText = Get-Content -LiteralPath $buildScript -Raw
if (-not $buildScriptText.Contains('Push-Location $projectRoot') -or -not $buildScriptText.Contains('dotnet tool run wix -- build')) {
    throw "build-msi.ps1 must run wix from the directory containing the pinned tool manifest"
}
if (-not $buildScriptText.Contains('"n\$([Guid]::NewGuid().ToString(''N'').Substring(0, 8))"') -or -not $buildScriptText.Contains('$payloadDir = Join-Path $stageRoot "p"')) {
    throw "build-msi.ps1 must use a short staging path for WiX compatibility"
}

$temp = Join-Path $env:TEMP "neuralese-msi-source-$([Guid]::NewGuid().ToString('N'))"
try {
    New-Item -ItemType Directory -Path (Join-Path $temp "payload\runtime") -Force | Out-Null
    Set-Content -LiteralPath (Join-Path $temp "payload\Neuralese.exe") -Value "fixture"
    Set-Content -LiteralPath (Join-Path $temp "payload\.neuralese-managed-install") -Value "NEURALESE_MANAGED_INSTALL_V1"
    Set-Content -LiteralPath (Join-Path $temp "payload\runtime\data.txt") -Value "fixture"

    $first = Join-Path $temp "Payload.first.wxs"
    $second = Join-Path $temp "Payload.second.wxs"
    & $generator -PayloadDir (Join-Path $temp "payload") -GameExeName "Neuralese.exe" -OutputPath $first
    & $generator -PayloadDir (Join-Path $temp "payload") -GameExeName "Neuralese.exe" -OutputPath $second

    $firstText = Get-Content -LiteralPath $first -Raw
    $secondText = Get-Content -LiteralPath $second -Raw
    if ($firstText -cne $secondText) {
        throw "Payload generation is not deterministic"
    }
    foreach ($expected in @('Id="NeuraleseExecutable"', 'Id="PayloadComponents"', '.neuralese-managed-install', 'runtime\data.txt')) {
        if (-not $firstText.Contains($expected)) {
            throw "Generated payload source is missing: $expected"
        }
    }

    Remove-Item -LiteralPath (Join-Path $temp "payload\Neuralese.exe") -Force
    $missingExeFailed = $false
    try {
        & $generator -PayloadDir (Join-Path $temp "payload") -GameExeName "Neuralese.exe" -OutputPath $second
    }
    catch {
        $missingExeFailed = $true
    }
    if (-not $missingExeFailed) {
        throw "Payload generation accepted a payload without Neuralese.exe"
    }
}
finally {
    Remove-Item -LiteralPath $temp -Recurse -Force -ErrorAction SilentlyContinue
}

Write-Host "PASS msi-source-tests"
