use std::{
    env,
    fs::{self, File},
    io::Write,
    path::PathBuf,
    thread,
    time::Duration,
};

const VERSION: &str = "9.9.9";

fn argument(prefix: &str) -> Option<String> {
    env::args().find_map(|value| value.strip_prefix(prefix).map(str::to_owned))
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let health_file = argument("--post-update-health-file=")
        .ok_or("missing post-update health file")?;
    let token = argument("--post-update-token=").ok_or("missing post-update token")?;
    if token.len() != 36 || !token.is_ascii() {
        return Err("invalid post-update token".into());
    }

    let target = PathBuf::from(health_file);
    let temporary = target.with_extension(format!("json.tmp.{}", std::process::id()));
    let mut output = File::create(&temporary)?;
    write!(
        output,
        "{{\"token\":\"{token}\",\"version\":\"{VERSION}\",\"pid\":{}}}",
        std::process::id()
    )?;
    output.sync_all()?;
    fs::rename(temporary, target)?;
    thread::sleep(Duration::from_secs(2));
    Ok(())
}
