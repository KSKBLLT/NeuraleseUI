$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$repo = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
$root = Join-Path $env:RUNNER_TEMP "neuralese updater smoke"
$payloadDir = Join-Path $root "payload"
$payloadZip = Join-Path $root "payload.zip"
$installDir = Join-Path $root "installed Neuralese"
$releaseDir = Join-Path $root "release"
$fakeExe = Join-Path $payloadDir "Neuralese.exe"
$roundTripDir = Join-Path $root "round trip"

Remove-Item -LiteralPath $root -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Path $payloadDir, $installDir, $releaseDir -Force | Out-Null

& rustc (Join-Path $PSScriptRoot "fake_neuralese.rs") -O -o $fakeExe
if ($LASTEXITCODE -ne 0) { throw "Could not compile fake Neuralese executable" }
$expectedHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $fakeExe).Hash
$expectedLength = (Get-Item -LiteralPath $fakeExe).Length
Compress-Archive -Path (Join-Path $payloadDir "*") -DestinationPath $payloadZip -CompressionLevel Optimal
Expand-Archive -LiteralPath $payloadZip -DestinationPath $roundTripDir
$roundTripExe = Join-Path $roundTripDir "Neuralese.exe"
$roundTripHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $roundTripExe).Hash
if ($roundTripHash -ne $expectedHash) {
    throw "Payload ZIP round trip changed Neuralese.exe: expected $expectedHash, got $roundTripHash"
}

Set-Content -LiteralPath (Join-Path $installDir ".neuralese-install-marker") -Encoding ASCII -NoNewline `
    -Value "NEURALESE_INSTALL_MARKER_V1:Neuralese"
Set-Content -LiteralPath (Join-Path $installDir ".neuralese-install-manifest.json") -Encoding UTF8 `
    -Value '{"schema_version":1,"app_version":"9.9.8","install_root":"smoke"}'
Set-Content -LiteralPath (Join-Path $installDir "Neuralese.exe") -Encoding ASCII -NoNewline `
    -Value "old executable"
$oldHash = (Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $installDir "Neuralese.exe")).Hash

& (Join-Path $repo "build.ps1") `
    -PayloadZip $payloadZip `
    -LogoPng (Join-Path $repo "public\logo.png") `
    -AppName "Neuralese" `
    -GameExeName "Neuralese.exe" `
    -AppVersion "9.9.9" `
    -OutputDir $releaseDir
if ($LASTEXITCODE -ne 0) { throw "Setup build failed" }

$setupExe = Join-Path $releaseDir "Neuralese-Setup.exe"
if (-not (Test-Path -LiteralPath $setupExe -PathType Leaf)) { throw "Setup executable is missing" }
$oldProcess = Start-Process powershell.exe -ArgumentList @(
    "-NoProfile", "-Command", "Start-Sleep -Seconds 1"
) -PassThru

$updateProcess = Start-Process -FilePath $setupExe -ArgumentList @(
    "--silent-update",
    "--install-dir",
    "`"$installDir`"",
    "--wait-pid",
    $oldProcess.Id,
    "--launch-after-update"
) -Wait -PassThru
if ($updateProcess.ExitCode -ne 0) {
    throw "Silent updater exited with code $($updateProcess.ExitCode)"
}

$actualHash = (Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $installDir "Neuralese.exe")).Hash
$actualLength = (Get-Item -LiteralPath (Join-Path $installDir "Neuralese.exe")).Length
if ($actualHash -ne $expectedHash) {
    throw "Installed executable does not match the payload: expected $expectedHash ($expectedLength bytes), got $actualHash ($actualLength bytes), old was $oldHash"
}
$manifest = Get-Content -LiteralPath (Join-Path $installDir ".neuralese-install-manifest.json") -Raw | ConvertFrom-Json
if ($manifest.app_version -ne "9.9.9") { throw "Install manifest version was not updated" }
if (-not (Test-Path -LiteralPath (Join-Path $installDir ".neuralese-install-marker"))) {
    throw "Install marker was not preserved"
}

$parent = Split-Path -Parent $installDir
if (Get-ChildItem -LiteralPath $parent -Directory | Where-Object {
    $_.Name -like ".neuralese-backup-*" -or $_.Name -like ".neuralese-stage-*"
}) { throw "Updater left a backup or staging directory after health success" }
if (Test-Path -LiteralPath (Join-Path $parent ".neuralese-update.lock")) {
    throw "Updater lock was not released"
}

Write-Host "PASS silent-update-smoke"
