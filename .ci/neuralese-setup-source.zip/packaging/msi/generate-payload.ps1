param(
    [Parameter(Mandatory = $true)]
    [string]$PayloadDir,

    [string]$GameExeName = "Neuralese.exe",

    [Parameter(Mandatory = $true)]
    [string]$OutputPath
)

$ErrorActionPreference = "Stop"

function Escape-Xml([string]$Value) {
    return [System.Security.SecurityElement]::Escape($Value)
}

function Stable-Id([string]$Prefix, [string]$Value) {
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($Value.ToLowerInvariant())
        $hash = $sha.ComputeHash($bytes)
        $hex = -join ($hash[0..11] | ForEach-Object { $_.ToString("x2") })
        return "$Prefix$hex"
    }
    finally {
        $sha.Dispose()
    }
}

$payloadRoot = (Resolve-Path -LiteralPath $PayloadDir).Path
$outputFull = [System.IO.Path]::GetFullPath($OutputPath)
$files = @(
    Get-ChildItem -LiteralPath $payloadRoot -File -Recurse |
        Sort-Object { [System.IO.Path]::GetRelativePath($payloadRoot, $_.FullName).Replace("\", "/").ToLowerInvariant() }
)

if ($files.Count -eq 0) {
    throw "MSI payload is empty: $payloadRoot"
}

$executables = @($files | Where-Object { $_.Name -ieq $GameExeName })
if ($executables.Count -ne 1) {
    throw "MSI payload must contain exactly one '$GameExeName'; found $($executables.Count)"
}

$lines = [System.Collections.Generic.List[string]]::new()
$lines.Add('<?xml version="1.0" encoding="utf-8"?>')
$lines.Add('<Wix xmlns="http://wixtoolset.org/schemas/v4/wxs">')
$lines.Add('  <Fragment>')
$lines.Add('    <ComponentGroup Id="PayloadComponents">')

foreach ($file in $files) {
    $relative = [System.IO.Path]::GetRelativePath($payloadRoot, $file.FullName).Replace("/", "\")
    $relativeUnix = $relative.Replace("\", "/")
    $componentId = Stable-Id "cmp_" $relativeUnix
    $fileId = if ($file.FullName -eq $executables[0].FullName) {
        "NeuraleseExecutable"
    }
    else {
        Stable-Id "fil_" $relativeUnix
    }
    $subdirectory = [System.IO.Path]::GetDirectoryName($relative)
    $subdirectoryAttribute = if ([string]::IsNullOrWhiteSpace($subdirectory)) {
        ""
    }
    else {
        ' Subdirectory="' + (Escape-Xml $subdirectory) + '"'
    }
    $source = Escape-Xml $file.FullName
    $lines.Add(('      <Component Id="{0}" Directory="INSTALLFOLDER"{1} Guid="*" Bitness="always64">' -f $componentId, $subdirectoryAttribute))
    $lines.Add(('        <File Id="{0}" Source="{1}" KeyPath="yes" />' -f $fileId, $source))
    $lines.Add('      </Component>')
}

$lines.Add('    </ComponentGroup>')
$lines.Add('  </Fragment>')
$lines.Add('</Wix>')

New-Item -ItemType Directory -Path (Split-Path -Parent $outputFull) -Force | Out-Null
[System.IO.File]::WriteAllLines($outputFull, $lines, [System.Text.UTF8Encoding]::new($false))
Write-Host "Generated deterministic WiX payload source: $outputFull"
