param(
    [Parameter(Mandatory = $true)]
    [string]$PayloadZip,

    [string]$LogoPng = ".\public\logo.png",
    [string]$AppName = "Neuralese",
    [string]$GameExeName = "Neuralese.exe",
    [string]$AppVersion = "0.1.0",
    [string]$OutputDir = ".\release"
)

$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$ErrorActionPreference = "Stop"

& (Join-Path $ProjectRoot "build.ps1") `
    -PayloadZip $PayloadZip `
    -LogoPng $LogoPng `
    -AppName $AppName `
    -GameExeName $GameExeName `
    -AppVersion $AppVersion `
    -OutputDir $OutputDir
