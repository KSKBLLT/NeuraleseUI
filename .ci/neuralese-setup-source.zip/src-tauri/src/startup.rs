#[cfg(any(windows, test))]
use std::path::{Path, PathBuf};
use std::{
    any::Any,
    panic::{catch_unwind, AssertUnwindSafe},
};

pub const SLINT_BACKEND: &str = "winit";
pub const SLINT_RENDERER: &str = "software";

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum StartupMode {
    Slint,
    NativeFallback,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
#[cfg(any(windows, test))]
pub enum InstallLocationChoice {
    Default,
    Browse,
    Cancel,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
#[cfg(any(windows, test))]
pub enum FallbackOutcome {
    Installed,
    Cancelled,
}

#[cfg(any(windows, test))]
pub trait FallbackUi {
    fn choose_install_location(
        &mut self,
        default_dir: &Path,
        slint_error: &str,
    ) -> InstallLocationChoice;
    fn browse_for_install_location(&mut self, default_dir: &Path) -> Option<PathBuf>;
    fn show_install_success(&mut self, install_dir: &Path) -> bool;
    fn show_install_error(&mut self, error: &str);
}

#[cfg(windows)]
pub struct WindowsFallbackUi {
    title: String,
}

#[cfg(windows)]
impl WindowsFallbackUi {
    pub fn new(app_name: &str) -> Self {
        Self {
            title: format!("{app_name} Setup"),
        }
    }
}

#[cfg(windows)]
impl FallbackUi for WindowsFallbackUi {
    fn choose_install_location(
        &mut self,
        default_dir: &Path,
        slint_error: &str,
    ) -> InstallLocationChoice {
        use rfd::{MessageButtons, MessageDialog, MessageDialogResult, MessageLevel};

        let description = format!(
            "The enhanced installer interface could not start, so Windows compatibility mode is active.\n\nDefault install location:\n{}\n\nYes: install here\nNo: choose another folder\nCancel: exit setup\n\nTechnical details: {}",
            default_dir.display(),
            slint_error
        );

        match MessageDialog::new()
            .set_title(&self.title)
            .set_description(description)
            .set_level(MessageLevel::Warning)
            .set_buttons(MessageButtons::YesNoCancel)
            .show()
        {
            MessageDialogResult::Yes => InstallLocationChoice::Default,
            MessageDialogResult::No => InstallLocationChoice::Browse,
            _ => InstallLocationChoice::Cancel,
        }
    }

    fn browse_for_install_location(&mut self, default_dir: &Path) -> Option<PathBuf> {
        rfd::FileDialog::new()
            .set_title("Choose Neuralese install folder")
            .set_directory(default_dir)
            .pick_folder()
    }

    fn show_install_success(&mut self, install_dir: &Path) -> bool {
        use rfd::{MessageButtons, MessageDialog, MessageDialogResult, MessageLevel};

        let description = format!(
            "Neuralese was installed successfully to:\n{}\n\nLaunch Neuralese now?",
            install_dir.display()
        );

        matches!(
            MessageDialog::new()
                .set_title(&self.title)
                .set_description(description)
                .set_level(MessageLevel::Info)
                .set_buttons(MessageButtons::YesNo)
                .show(),
            MessageDialogResult::Yes
        )
    }

    fn show_install_error(&mut self, error: &str) {
        use rfd::{MessageButtons, MessageDialog, MessageLevel};

        MessageDialog::new()
            .set_title(&self.title)
            .set_description(format!("Neuralese Setup could not finish.\n\n{error}"))
            .set_level(MessageLevel::Error)
            .set_buttons(MessageButtons::Ok)
            .show();
    }
}

pub fn run_with_native_fallback<G, F>(gui: G, fallback: F) -> Result<StartupMode, String>
where
    G: FnOnce() -> Result<(), String>,
    F: FnOnce(&str) -> Result<(), String>,
{
    let gui_result = catch_unwind(AssertUnwindSafe(gui));
    let primary_error = match gui_result {
        Ok(Ok(())) => return Ok(StartupMode::Slint),
        Ok(Err(error)) => error,
        Err(payload) => format!("Slint UI panicked: {}", panic_message(payload.as_ref())),
    };

    fallback(&primary_error).map_err(|fallback_error| {
        format!("Slint UI failed ({primary_error}); Windows fallback failed ({fallback_error})")
    })?;

    Ok(StartupMode::NativeFallback)
}

#[cfg(any(windows, test))]
pub fn run_native_install_flow<U, I, L>(
    ui: &mut U,
    default_dir: &Path,
    slint_error: &str,
    mut install: I,
    mut launch: L,
) -> Result<FallbackOutcome, String>
where
    U: FallbackUi,
    I: FnMut(&Path) -> Result<(), String>,
    L: FnMut(&Path) -> Result<(), String>,
{
    let install_dir = match ui.choose_install_location(default_dir, slint_error) {
        InstallLocationChoice::Default => default_dir.to_path_buf(),
        InstallLocationChoice::Browse => match ui.browse_for_install_location(default_dir) {
            Some(path) => path,
            None => return Ok(FallbackOutcome::Cancelled),
        },
        InstallLocationChoice::Cancel => return Ok(FallbackOutcome::Cancelled),
    };

    if let Err(error) = install(&install_dir) {
        ui.show_install_error(&error);
        return Err(error);
    }

    if ui.show_install_success(&install_dir) {
        if let Err(error) = launch(&install_dir) {
            ui.show_install_error(&error);
            return Err(error);
        }
    }

    Ok(FallbackOutcome::Installed)
}

fn panic_message(payload: &(dyn Any + Send)) -> String {
    if let Some(message) = payload.downcast_ref::<String>() {
        return message.clone();
    }
    if let Some(message) = payload.downcast_ref::<&str>() {
        return (*message).to_string();
    }
    "unknown panic".to_string()
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::{cell::Cell, path::PathBuf};

    #[test]
    fn installer_renderer_is_software_only() {
        assert_eq!(SLINT_BACKEND, "winit");
        assert_eq!(SLINT_RENDERER, "software");
    }

    #[test]
    fn successful_slint_ui_does_not_run_native_fallback() {
        let fallback_called = Cell::new(false);

        let result = run_with_native_fallback(
            || Ok(()),
            |_| {
                fallback_called.set(true);
                Ok(())
            },
        );

        assert_eq!(result, Ok(StartupMode::Slint));
        assert!(!fallback_called.get());
    }

    #[test]
    fn slint_error_runs_native_fallback() {
        let reason = std::cell::RefCell::new(String::new());

        let result = run_with_native_fallback(
            || Err("renderer unavailable".to_string()),
            |error| {
                *reason.borrow_mut() = error.to_string();
                Ok(())
            },
        );

        assert_eq!(result, Ok(StartupMode::NativeFallback));
        assert_eq!(reason.borrow().as_str(), "renderer unavailable");
    }

    #[test]
    fn slint_panic_runs_native_fallback() {
        let fallback_called = Cell::new(false);

        let result = run_with_native_fallback(
            || panic!("window creation failed"),
            |error| {
                fallback_called.set(true);
                assert!(error.contains("window creation failed"));
                Ok(())
            },
        );

        assert_eq!(result, Ok(StartupMode::NativeFallback));
        assert!(fallback_called.get());
    }

    struct FakeFallbackUi {
        choice: InstallLocationChoice,
        browse_result: Option<PathBuf>,
        error: Option<String>,
        success_shown: bool,
    }

    impl FallbackUi for FakeFallbackUi {
        fn choose_install_location(
            &mut self,
            _default_dir: &std::path::Path,
            _slint_error: &str,
        ) -> InstallLocationChoice {
            self.choice
        }

        fn browse_for_install_location(
            &mut self,
            _default_dir: &std::path::Path,
        ) -> Option<PathBuf> {
            self.browse_result.clone()
        }

        fn show_install_success(&mut self, _install_dir: &std::path::Path) -> bool {
            self.success_shown = true;
            false
        }

        fn show_install_error(&mut self, error: &str) {
            self.error = Some(error.to_string());
        }
    }

    #[test]
    fn native_fallback_installs_to_default_location() {
        let default_dir = PathBuf::from(r"C:\Users\Student\AppData\Local\Programs\Neuralese");
        let installed_at = std::cell::RefCell::new(None);
        let mut ui = FakeFallbackUi {
            choice: InstallLocationChoice::Default,
            browse_result: None,
            error: None,
            success_shown: false,
        };

        let result = run_native_install_flow(
            &mut ui,
            &default_dir,
            "Slint failed",
            |path| {
                *installed_at.borrow_mut() = Some(path.to_path_buf());
                Ok(())
            },
            |_| Ok(()),
        );

        assert_eq!(result, Ok(FallbackOutcome::Installed));
        assert_eq!(installed_at.into_inner(), Some(default_dir));
        assert!(ui.success_shown);
        assert_eq!(ui.error, None);
    }

    #[test]
    fn native_fallback_cancel_does_not_install() {
        let install_called = Cell::new(false);
        let mut ui = FakeFallbackUi {
            choice: InstallLocationChoice::Cancel,
            browse_result: None,
            error: None,
            success_shown: false,
        };

        let result = run_native_install_flow(
            &mut ui,
            std::path::Path::new(r"C:\Neuralese"),
            "Slint failed",
            |_| {
                install_called.set(true);
                Ok(())
            },
            |_| Ok(()),
        );

        assert_eq!(result, Ok(FallbackOutcome::Cancelled));
        assert!(!install_called.get());
        assert!(!ui.success_shown);
    }

    #[test]
    fn native_fallback_installs_to_browsed_location() {
        let selected_dir = PathBuf::from(r"D:\Neuralese");
        let installed_at = std::cell::RefCell::new(None);
        let mut ui = FakeFallbackUi {
            choice: InstallLocationChoice::Browse,
            browse_result: Some(selected_dir.clone()),
            error: None,
            success_shown: false,
        };

        let result = run_native_install_flow(
            &mut ui,
            std::path::Path::new(r"C:\Neuralese"),
            "Slint failed",
            |path| {
                *installed_at.borrow_mut() = Some(path.to_path_buf());
                Ok(())
            },
            |_| Ok(()),
        );

        assert_eq!(result, Ok(FallbackOutcome::Installed));
        assert_eq!(installed_at.into_inner(), Some(selected_dir));
        assert!(ui.success_shown);
    }

    #[test]
    fn native_fallback_reports_install_error() {
        let mut ui = FakeFallbackUi {
            choice: InstallLocationChoice::Default,
            browse_result: None,
            error: None,
            success_shown: false,
        };

        let result = run_native_install_flow(
            &mut ui,
            std::path::Path::new(r"C:\Neuralese"),
            "Slint failed",
            |_| Err("payload is damaged".to_string()),
            |_| Ok(()),
        );

        assert_eq!(result, Err("payload is damaged".to_string()));
        assert_eq!(ui.error.as_deref(), Some("payload is damaged"));
        assert!(!ui.success_shown);
    }
}
