use clap::Parser;
use std::path::PathBuf;

#[derive(Debug, Parser)]
#[command(name = "Neuralese-Setup", disable_help_subcommand = true)]
pub struct Cli {
    #[arg(long)]
    silent_update: bool,

    #[arg(
        long,
        value_name = "PATH",
        requires = "silent_update",
        required_if_eq("silent_update", "true")
    )]
    install_dir: Option<PathBuf>,

    #[arg(
        long,
        value_name = "PID",
        requires = "silent_update",
        required_if_eq("silent_update", "true")
    )]
    wait_pid: Option<u32>,

    #[arg(long, requires = "silent_update")]
    launch_after_update: bool,
}

#[derive(Debug, PartialEq, Eq)]
pub enum LaunchMode {
    Gui,
    SilentUpdate {
        install_dir: PathBuf,
        wait_pid: u32,
        launch_after_update: bool,
    },
}

impl Cli {
    pub fn launch_mode(&self) -> Result<LaunchMode, String> {
        if !self.silent_update {
            return Ok(LaunchMode::Gui);
        }
        let install_dir = self
            .install_dir
            .clone()
            .ok_or("--install-dir is required for --silent-update")?;
        let wait_pid = self
            .wait_pid
            .ok_or("--wait-pid is required for --silent-update")?;
        if wait_pid == 0 {
            return Err("--wait-pid must be greater than zero".to_string());
        }
        Ok(LaunchMode::SilentUpdate {
            install_dir,
            wait_pid,
            launch_after_update: self.launch_after_update,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::{Cli, LaunchMode};
    use clap::Parser;
    use std::path::PathBuf;

    #[test]
    fn no_arguments_selects_gui_mode() {
        let cli = Cli::try_parse_from(["Neuralese-Setup.exe"]).expect("GUI args");
        assert_eq!(cli.launch_mode().expect("GUI mode"), LaunchMode::Gui);
    }

    #[test]
    fn silent_update_requires_install_directory() {
        let result = Cli::try_parse_from([
            "Neuralese-Setup.exe",
            "--silent-update",
            "--wait-pid",
            "1234",
        ]);
        assert!(result.is_err());
    }

    #[test]
    fn silent_update_rejects_nonnumeric_pid() {
        let result = Cli::try_parse_from([
            "Neuralese-Setup.exe",
            "--silent-update",
            "--install-dir",
            r"C:\Users\student\Neuralese",
            "--wait-pid",
            "not-a-pid",
        ]);
        assert!(result.is_err());
    }

    #[test]
    fn silent_update_rejects_zero_pid() {
        let cli = Cli::try_parse_from([
            "Neuralese-Setup.exe",
            "--silent-update",
            "--install-dir",
            r"C:\Users\student\Neuralese",
            "--wait-pid",
            "0",
        ])
        .expect("numeric PID parses");

        assert!(cli.launch_mode().is_err());
    }

    #[test]
    fn silent_update_returns_typed_options() {
        let cli = Cli::try_parse_from([
            "Neuralese-Setup.exe",
            "--silent-update",
            "--install-dir",
            r"C:\Users\student\Neuralese",
            "--wait-pid",
            "1234",
            "--launch-after-update",
        ])
        .expect("silent update args");

        let mode = cli.launch_mode().expect("silent update mode");
        assert_eq!(
            mode,
            LaunchMode::SilentUpdate {
                install_dir: PathBuf::from(r"C:\Users\student\Neuralese"),
                wait_pid: 1234,
                launch_after_update: true,
            }
        );
    }
}
