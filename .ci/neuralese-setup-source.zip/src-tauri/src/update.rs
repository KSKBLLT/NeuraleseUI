#![cfg_attr(not(windows), allow(dead_code))]

#[cfg(windows)]
use fs2::available_space;
use serde::Deserialize;
use std::{
    fs::{self, File, OpenOptions},
    io::{self, Cursor, Write},
    path::{Path, PathBuf},
    time::Duration,
};
#[cfg(windows)]
use std::{
    process::{Child, Command},
    thread,
    time::Instant,
};
use uuid::Uuid;
use zip::ZipArchive;

pub(crate) const MARKER_FILE: &str = ".neuralese-install-marker";
const MANIFEST_FILE: &str = ".neuralese-install-manifest.json";
const UNINSTALL_PS1: &str = "uninstall.ps1";
const UNINSTALL_VBS: &str = "uninstall.vbs";
#[cfg(windows)]
const PROCESS_WAIT_TIMEOUT: Duration = Duration::from_secs(60);
#[cfg(windows)]
const HEALTH_TIMEOUT: Duration = Duration::from_secs(45);

#[derive(Clone, Debug)]
pub struct SilentUpdateOptions {
    pub install_dir: PathBuf,
    pub wait_pid: u32,
    pub launch_after_update: bool,
}

#[allow(clippy::enum_variant_names)]
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum FailurePoint {
    AfterStaging,
    AfterBackupRename,
    AfterInstallRename,
}

struct UpdateConfig<'a> {
    payload: &'a [u8],
    app_name: &'a str,
    app_version: &'a str,
    game_exe_name: &'a str,
    updater_dir: &'a Path,
    wait_timeout: Duration,
    health_timeout: Duration,
    failure_point: Option<FailurePoint>,
}

trait UpdateRuntime {
    type Child;

    fn wait_for_process_exit(&mut self, pid: u32, timeout: Duration) -> Result<(), String>;
    fn is_process_running(&mut self, pid: u32) -> bool;
    fn available_space(&mut self, path: &Path) -> Result<u64, String>;
    fn launch(&mut self, executable: &Path, args: &[String]) -> Result<Self::Child, String>;
    fn wait_for_health(
        &mut self,
        child: &mut Self::Child,
        health_file: &Path,
        token: &str,
        version: &str,
        timeout: Duration,
    ) -> Result<(), String>;
    fn terminate(&mut self, child: &mut Self::Child);
}

#[cfg(windows)]
struct SystemRuntime;

#[cfg(windows)]
impl UpdateRuntime for SystemRuntime {
    type Child = Child;

    fn wait_for_process_exit(&mut self, pid: u32, timeout: Duration) -> Result<(), String> {
        wait_for_process_exit(pid, timeout)
    }

    fn is_process_running(&mut self, pid: u32) -> bool {
        is_process_running(pid)
    }

    fn available_space(&mut self, path: &Path) -> Result<u64, String> {
        available_space(path)
            .map_err(|error| format!("Failed to inspect available disk space: {error}"))
    }

    fn launch(&mut self, executable: &Path, args: &[String]) -> Result<Self::Child, String> {
        Command::new(executable)
            .args(args)
            .current_dir(executable.parent().unwrap_or(Path::new(".")))
            .spawn()
            .map_err(|error| format!("Failed to launch {}: {error}", executable.display()))
    }

    fn wait_for_health(
        &mut self,
        child: &mut Self::Child,
        health_file: &Path,
        token: &str,
        version: &str,
        timeout: Duration,
    ) -> Result<(), String> {
        wait_for_health(child, health_file, token, version, timeout)
    }

    fn terminate(&mut self, child: &mut Self::Child) {
        let _ = child.kill();
        let _ = child.wait();
    }
}

#[cfg(windows)]
pub fn run_silent_update(options: SilentUpdateOptions) -> Result<(), String> {
    let current_exe = std::env::current_exe()
        .map_err(|error| format!("Could not locate the updater executable: {error}"))?;
    let updater_dir = current_exe
        .parent()
        .ok_or("Could not locate the updater directory")?;
    let config = UpdateConfig {
        payload: crate::PAYLOAD_ZIP,
        app_name: crate::app_name(),
        app_version: crate::app_version(),
        game_exe_name: crate::game_exe_name(),
        updater_dir,
        wait_timeout: PROCESS_WAIT_TIMEOUT,
        health_timeout: HEALTH_TIMEOUT,
        failure_point: None,
    };
    run_silent_update_with_runtime(options, config, &mut SystemRuntime)
}

#[cfg(not(windows))]
pub fn run_silent_update(_options: SilentUpdateOptions) -> Result<(), String> {
    Err("Silent updates are currently supported only on Windows".to_string())
}

fn run_silent_update_with_runtime<R: UpdateRuntime>(
    options: SilentUpdateOptions,
    config: UpdateConfig<'_>,
    runtime: &mut R,
) -> Result<(), String> {
    validate_marked_installation(&options.install_dir, config.app_name)?;
    let _lock = UpdateLock::acquire(&options.install_dir, runtime)?;
    runtime.wait_for_process_exit(options.wait_pid, config.wait_timeout)?;

    let install_parent = options
        .install_dir
        .parent()
        .ok_or("Install directory has no parent")?;
    let current_size = directory_size(&options.install_dir)?;
    let required_space = (config.payload.len() as u64)
        .checked_mul(2)
        .and_then(|size| size.checked_add(current_size))
        .ok_or("Required disk space calculation overflowed")?;
    let free_space = match runtime.available_space(install_parent) {
        Ok(value) => value,
        Err(error) => {
            relaunch_old_if_requested(&options, config.game_exe_name, runtime);
            return Err(error);
        }
    };
    if free_space < required_space {
        relaunch_old_if_requested(&options, config.game_exe_name, runtime);
        return Err(format!(
            "Insufficient disk space: need {required_space} bytes, have {free_space} bytes"
        ));
    }

    let transaction_id = Uuid::new_v4().simple().to_string();
    let stage_dir = install_parent.join(format!(".neuralese-stage-{transaction_id}"));
    let backup_dir = install_parent.join(format!(".neuralese-backup-{transaction_id}"));
    let health_dir = config.updater_dir.join("health");
    let health_file = health_dir.join(format!("{transaction_id}.json"));
    let token = Uuid::new_v4().to_string();
    let mut child: Option<R::Child> = None;

    let result = (|| {
        let staged_payload = stage_payload(config.payload, &stage_dir, config.game_exe_name)?;
        if !staged_payload.game_executable.starts_with(&stage_dir) {
            return Err("Staged executable escaped the staging directory".to_string());
        }
        copy_installer_metadata(&options.install_dir, &stage_dir, config.app_version)?;
        maybe_fail(config.failure_point, FailurePoint::AfterStaging)?;

        if config.failure_point.is_none() {
            swap_installation(&options.install_dir, &stage_dir, &backup_dir)?;
        } else {
            swap_installation_with_failure(
                &options.install_dir,
                &stage_dir,
                &backup_dir,
                config.failure_point,
            )?;
        }

        fs::create_dir_all(&health_dir)
            .map_err(|error| format!("Failed to create health directory: {error}"))?;
        remove_path_if_exists(&health_file)?;
        let game_exe = find_game_executable(&options.install_dir, config.game_exe_name)?;
        let args = vec![
            format!("--post-update-health-file={}", health_file.display()),
            format!("--post-update-token={token}"),
        ];
        child = Some(runtime.launch(&game_exe, &args)?);
        let active_child = child.as_mut().expect("child set after successful launch");
        runtime.wait_for_health(
            active_child,
            &health_file,
            &token,
            config.app_version,
            config.health_timeout,
        )?;

        remove_path_if_exists(&backup_dir)?;
        remove_path_if_exists(&health_file)?;
        if !options.launch_after_update {
            runtime.terminate(active_child);
        }
        Ok(())
    })();

    if let Err(error) = result {
        if let Some(active_child) = child.as_mut() {
            runtime.terminate(active_child);
        }
        let had_backup = backup_dir.exists();
        let rollback_result = rollback_installation(&options.install_dir, &backup_dir);
        let _ = remove_path_if_exists(&stage_dir);
        let _ = remove_path_if_exists(&health_file);
        if had_backup || options.install_dir.exists() {
            relaunch_old_if_requested(&options, config.game_exe_name, runtime);
        }
        if let Err(rollback_error) = rollback_result {
            return Err(format!("{error}; rollback failed: {rollback_error}"));
        }
        return Err(error);
    }

    let _ = remove_path_if_exists(&stage_dir);
    Ok(())
}

fn relaunch_old_if_requested<R: UpdateRuntime>(
    options: &SilentUpdateOptions,
    game_exe_name: &str,
    runtime: &mut R,
) {
    if !options.launch_after_update {
        return;
    }
    if let Ok(old_exe) = find_game_executable(&options.install_dir, game_exe_name) {
        let _ = runtime.launch(&old_exe, &[]);
    }
}

fn validate_marked_installation(install_dir: &Path, app_name: &str) -> Result<(), String> {
    if !install_dir.is_dir() {
        return Err("Install directory does not exist".to_string());
    }
    let marker = fs::read_to_string(install_dir.join(MARKER_FILE))
        .map_err(|_| "Install marker is missing".to_string())?;
    if marker.trim() != expected_marker(app_name) {
        return Err("Install marker is invalid".to_string());
    }
    Ok(())
}

pub(crate) fn expected_marker(app_name: &str) -> String {
    let registry_key = app_name
        .chars()
        .filter(|character| {
            character.is_ascii_alphanumeric() || *character == '-' || *character == '_'
        })
        .collect::<String>();
    format!("NEURALESE_INSTALL_MARKER_V1:{registry_key}")
}

struct UpdateLock {
    path: PathBuf,
}

impl UpdateLock {
    fn acquire<R: UpdateRuntime>(install_dir: &Path, runtime: &mut R) -> Result<Self, String> {
        let path = update_lock_path(install_dir);
        if path.exists() {
            let pid = fs::read_to_string(&path)
                .ok()
                .and_then(|text| text.trim().parse::<u32>().ok());
            if pid.is_some_and(|value| runtime.is_process_running(value)) {
                return Err("Another updater is already running".to_string());
            }
            fs::remove_file(&path)
                .map_err(|error| format!("Failed to remove stale update lock: {error}"))?;
        }

        let mut file = OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(&path)
            .map_err(|error| format!("Failed to acquire update lock: {error}"))?;
        writeln!(file, "{}", std::process::id())
            .map_err(|error| format!("Failed to write update lock: {error}"))?;
        file.sync_all()
            .map_err(|error| format!("Failed to sync update lock: {error}"))?;
        Ok(Self { path })
    }
}

impl Drop for UpdateLock {
    fn drop(&mut self) {
        let _ = fs::remove_file(&self.path);
    }
}

fn update_lock_path(install_dir: &Path) -> PathBuf {
    install_dir
        .parent()
        .unwrap_or(install_dir)
        .join(".neuralese-update.lock")
}

#[derive(Debug)]
struct ExtractedPayload {
    game_executable: PathBuf,
}

fn stage_payload(
    payload: &[u8],
    stage_dir: &Path,
    game_exe_name: &str,
) -> Result<ExtractedPayload, String> {
    remove_path_if_exists(stage_dir)?;
    fs::create_dir_all(stage_dir)
        .map_err(|error| format!("Failed to create staging directory: {error}"))?;
    let mut archive = ZipArchive::new(Cursor::new(payload))
        .map_err(|error| format!("Invalid embedded payload zip: {error}"))?;

    for index in 0..archive.len() {
        let mut entry = archive
            .by_index(index)
            .map_err(|error| format!("Failed to read payload entry {index}: {error}"))?;
        let safe_name = entry
            .enclosed_name()
            .ok_or_else(|| format!("Unsafe zip path rejected: {}", entry.name()))?
            .to_owned();
        if entry
            .unix_mode()
            .is_some_and(|mode| mode & 0o170000 == 0o120000)
        {
            return Err(format!("Unsafe zip symlink rejected: {}", entry.name()));
        }
        let output_path = stage_dir.join(safe_name);
        if entry.is_dir() {
            fs::create_dir_all(&output_path).map_err(|error| {
                format!(
                    "Failed to create staged directory {}: {error}",
                    output_path.display()
                )
            })?;
            continue;
        }
        if let Some(parent) = output_path.parent() {
            fs::create_dir_all(parent).map_err(|error| {
                format!(
                    "Failed to create staged directory {}: {error}",
                    parent.display()
                )
            })?;
        }
        let mut output = File::create(&output_path).map_err(|error| {
            format!(
                "Failed to create staged file {}: {error}",
                output_path.display()
            )
        })?;
        io::copy(&mut entry, &mut output).map_err(|error| {
            format!(
                "Failed to extract staged file {}: {error}",
                output_path.display()
            )
        })?;
        output.sync_all().map_err(|error| {
            format!(
                "Failed to sync staged file {}: {error}",
                output_path.display()
            )
        })?;
    }

    let game_executable = find_game_executable(stage_dir, game_exe_name)?;
    Ok(ExtractedPayload { game_executable })
}

fn copy_installer_metadata(
    install_dir: &Path,
    stage_dir: &Path,
    app_version: &str,
) -> Result<(), String> {
    for filename in [MARKER_FILE, MANIFEST_FILE, UNINSTALL_PS1, UNINSTALL_VBS] {
        let source = install_dir.join(filename);
        if !source.is_file() {
            continue;
        }
        fs::copy(&source, stage_dir.join(filename)).map_err(|error| {
            format!("Failed to preserve installer metadata {filename}: {error}")
        })?;
    }
    update_staged_manifest_version(stage_dir, app_version)?;
    Ok(())
}

fn update_staged_manifest_version(stage_dir: &Path, app_version: &str) -> Result<(), String> {
    let manifest_path = stage_dir.join(MANIFEST_FILE);
    if !manifest_path.is_file() {
        return Ok(());
    }
    let content = fs::read(&manifest_path)
        .map_err(|error| format!("Failed to read staged install manifest: {error}"))?;
    let mut manifest: serde_json::Value = serde_json::from_slice(&content)
        .map_err(|error| format!("Invalid staged install manifest: {error}"))?;
    let object = manifest
        .as_object_mut()
        .ok_or("Staged install manifest must be a JSON object")?;
    object.insert(
        "app_version".to_string(),
        serde_json::Value::String(app_version.to_string()),
    );
    let mut serialized = serde_json::to_vec_pretty(&manifest)
        .map_err(|error| format!("Failed to serialize staged install manifest: {error}"))?;
    serialized.push(b'\n');
    let mut output = File::create(&manifest_path)
        .map_err(|error| format!("Failed to write staged install manifest: {error}"))?;
    output
        .write_all(&serialized)
        .map_err(|error| format!("Failed to write staged install manifest: {error}"))?;
    output
        .sync_all()
        .map_err(|error| format!("Failed to sync staged install manifest: {error}"))
}

fn swap_installation(
    install_dir: &Path,
    stage_dir: &Path,
    backup_dir: &Path,
) -> Result<(), String> {
    swap_installation_with_failure(install_dir, stage_dir, backup_dir, None)
}

fn swap_installation_with_failure(
    install_dir: &Path,
    stage_dir: &Path,
    backup_dir: &Path,
    failure_point: Option<FailurePoint>,
) -> Result<(), String> {
    let parent = install_dir
        .parent()
        .ok_or("Install directory has no parent")?;
    if stage_dir.parent() != Some(parent) || backup_dir.parent() != Some(parent) {
        return Err("Stage and backup must be sibling directories of the installation".to_string());
    }
    if backup_dir.exists() {
        return Err("Backup directory already exists".to_string());
    }
    fs::rename(install_dir, backup_dir)
        .map_err(|error| format!("Failed to move current installation to backup: {error}"))?;
    maybe_fail(failure_point, FailurePoint::AfterBackupRename)?;
    if let Err(error) = fs::rename(stage_dir, install_dir) {
        let _ = fs::rename(backup_dir, install_dir);
        return Err(format!("Failed to activate staged installation: {error}"));
    }
    maybe_fail(failure_point, FailurePoint::AfterInstallRename)
}

fn rollback_installation(install_dir: &Path, backup_dir: &Path) -> Result<(), String> {
    if !backup_dir.exists() {
        return if install_dir.exists() {
            Ok(())
        } else {
            Err("Neither installation nor backup exists".to_string())
        };
    }
    if install_dir.exists() {
        remove_path_if_exists(install_dir)?;
    }
    fs::rename(backup_dir, install_dir)
        .map_err(|error| format!("Failed to restore backup installation: {error}"))
}

fn maybe_fail(actual: Option<FailurePoint>, expected: FailurePoint) -> Result<(), String> {
    if actual == Some(expected) {
        return Err(format!("Injected failure at {expected:?}"));
    }
    Ok(())
}

fn find_game_executable(root: &Path, game_exe_name: &str) -> Result<PathBuf, String> {
    let mut matches = Vec::new();
    find_named_files(root, game_exe_name, &mut matches)?;
    match matches.len() {
        0 => Err(format!(
            "{game_exe_name} was not found in the staged payload"
        )),
        1 => Ok(matches.remove(0)),
        _ => Err(format!(
            "Multiple {game_exe_name} files were found in the payload"
        )),
    }
}

fn find_named_files(root: &Path, name: &str, matches: &mut Vec<PathBuf>) -> Result<(), String> {
    for entry in fs::read_dir(root)
        .map_err(|error| format!("Failed to inspect {}: {error}", root.display()))?
    {
        let entry = entry.map_err(|error| format!("Failed to inspect directory entry: {error}"))?;
        let path = entry.path();
        let metadata = fs::symlink_metadata(&path)
            .map_err(|error| format!("Failed to inspect {}: {error}", path.display()))?;
        if metadata.file_type().is_symlink() {
            continue;
        }
        if metadata.is_dir() {
            find_named_files(&path, name, matches)?;
        } else if entry
            .file_name()
            .to_string_lossy()
            .eq_ignore_ascii_case(name)
        {
            matches.push(path);
        }
    }
    Ok(())
}

fn directory_size(root: &Path) -> Result<u64, String> {
    let mut size = 0_u64;
    for entry in fs::read_dir(root)
        .map_err(|error| format!("Failed to inspect installation size: {error}"))?
    {
        let entry = entry.map_err(|error| format!("Failed to inspect installation: {error}"))?;
        let path = entry.path();
        let metadata = fs::symlink_metadata(&path)
            .map_err(|error| format!("Failed to inspect {}: {error}", path.display()))?;
        if metadata.file_type().is_symlink() {
            continue;
        }
        if metadata.is_dir() {
            size = size
                .checked_add(directory_size(&path)?)
                .ok_or("Installation size overflowed")?;
        } else {
            size = size
                .checked_add(metadata.len())
                .ok_or("Installation size overflowed")?;
        }
    }
    Ok(size)
}

fn remove_path_if_exists(path: &Path) -> Result<(), String> {
    if !path.exists() {
        return Ok(());
    }
    let metadata = fs::symlink_metadata(path)
        .map_err(|error| format!("Failed to inspect {}: {error}", path.display()))?;
    if metadata.is_dir() && !metadata.file_type().is_symlink() {
        fs::remove_dir_all(path)
            .map_err(|error| format!("Failed to remove {}: {error}", path.display()))
    } else {
        fs::remove_file(path)
            .map_err(|error| format!("Failed to remove {}: {error}", path.display()))
    }
}

#[derive(Deserialize)]
struct HealthMarker {
    token: String,
    version: String,
    pid: u32,
}

fn validate_health_marker(
    health_file: &Path,
    token: &str,
    version: &str,
    pid: u32,
) -> Result<(), String> {
    let content = fs::read_to_string(health_file)
        .map_err(|error| format!("Failed to read health marker: {error}"))?;
    let marker: HealthMarker = serde_json::from_str(&content)
        .map_err(|error| format!("Invalid health marker: {error}"))?;
    if marker.token != token || marker.version != version || marker.pid != pid {
        return Err("Health marker token, version, or PID did not match".to_string());
    }
    Ok(())
}

#[cfg(windows)]
fn wait_for_health(
    child: &mut Child,
    health_file: &Path,
    token: &str,
    version: &str,
    timeout: Duration,
) -> Result<(), String> {
    let started = Instant::now();
    while started.elapsed() < timeout {
        if let Some(status) = child
            .try_wait()
            .map_err(|error| format!("Failed to inspect updated process: {error}"))?
        {
            return Err(format!(
                "Updated process exited before health acknowledgement: {status}"
            ));
        }
        if health_file.is_file() {
            return validate_health_marker(health_file, token, version, child.id());
        }
        thread::sleep(Duration::from_millis(100));
    }
    Err("Timed out waiting for updated application health acknowledgement".to_string())
}

#[cfg(windows)]
fn wait_for_process_exit(pid: u32, timeout: Duration) -> Result<(), String> {
    use windows_sys::Win32::{
        Foundation::{CloseHandle, WAIT_OBJECT_0, WAIT_TIMEOUT},
        Storage::FileSystem::SYNCHRONIZE,
        System::Threading::{OpenProcess, WaitForSingleObject},
    };

    let handle = unsafe { OpenProcess(SYNCHRONIZE, 0, pid) };
    if handle.is_null() {
        return Ok(());
    }
    let timeout_ms = timeout.as_millis().min(u32::MAX as u128) as u32;
    let result = unsafe { WaitForSingleObject(handle, timeout_ms) };
    unsafe { CloseHandle(handle) };
    match result {
        WAIT_OBJECT_0 => Ok(()),
        WAIT_TIMEOUT => Err(format!("Timed out waiting for process {pid} to exit")),
        _ => Err(format!("Failed while waiting for process {pid}")),
    }
}

#[cfg(windows)]
fn is_process_running(pid: u32) -> bool {
    use windows_sys::Win32::{
        Foundation::{CloseHandle, WAIT_TIMEOUT},
        Storage::FileSystem::SYNCHRONIZE,
        System::Threading::{OpenProcess, WaitForSingleObject},
    };

    let handle = unsafe { OpenProcess(SYNCHRONIZE, 0, pid) };
    if handle.is_null() {
        return false;
    }
    let result = unsafe { WaitForSingleObject(handle, 0) } == WAIT_TIMEOUT;
    unsafe { CloseHandle(handle) };
    result
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::{
        fs,
        io::{Cursor, Write},
        path::{Path, PathBuf},
        time::Duration,
    };
    use tempfile::TempDir;
    use zip::{write::SimpleFileOptions, ZipWriter};

    const OLD_EXE: &[u8] = b"old executable";
    const NEW_EXE: &[u8] = b"new executable";

    #[derive(Default)]
    struct FakeRuntime {
        wait_error: Option<String>,
        launch_error: Option<String>,
        health_error: Option<String>,
        available_space: u64,
        launches: Vec<PathBuf>,
        terminated: usize,
        process_running: bool,
    }

    #[derive(Debug)]
    struct FakeChild;

    impl UpdateRuntime for FakeRuntime {
        type Child = FakeChild;

        fn wait_for_process_exit(&mut self, _pid: u32, _timeout: Duration) -> Result<(), String> {
            self.wait_error.clone().map_or(Ok(()), Err)
        }

        fn is_process_running(&mut self, _pid: u32) -> bool {
            self.process_running
        }

        fn available_space(&mut self, _path: &Path) -> Result<u64, String> {
            Ok(self.available_space)
        }

        fn launch(&mut self, executable: &Path, _args: &[String]) -> Result<Self::Child, String> {
            if let Some(error) = &self.launch_error {
                return Err(error.clone());
            }
            self.launches.push(executable.to_path_buf());
            Ok(FakeChild)
        }

        fn wait_for_health(
            &mut self,
            _child: &mut Self::Child,
            _health_file: &Path,
            _token: &str,
            _version: &str,
            _timeout: Duration,
        ) -> Result<(), String> {
            self.health_error.clone().map_or(Ok(()), Err)
        }

        fn terminate(&mut self, _child: &mut Self::Child) {
            self.terminated += 1;
        }
    }

    fn make_install(root: &Path, with_marker: bool) -> PathBuf {
        let install = root.join("Neuralese");
        fs::create_dir_all(&install).expect("install dir");
        fs::write(install.join("Neuralese.exe"), OLD_EXE).expect("old executable");
        if with_marker {
            fs::write(install.join(MARKER_FILE), expected_marker("Neuralese")).expect("marker");
        }
        install
    }

    fn payload(entries: &[(&str, &[u8])]) -> Vec<u8> {
        let mut writer = ZipWriter::new(Cursor::new(Vec::new()));
        for (name, bytes) in entries {
            writer
                .start_file(name, SimpleFileOptions::default())
                .expect("zip entry");
            writer.write_all(bytes).expect("zip bytes");
        }
        writer.finish().expect("finish zip").into_inner()
    }

    fn options(install_dir: &Path) -> SilentUpdateOptions {
        SilentUpdateOptions {
            install_dir: install_dir.to_path_buf(),
            wait_pid: 100,
            launch_after_update: true,
        }
    }

    fn config<'a>(payload: &'a [u8], updater_dir: &'a Path) -> UpdateConfig<'a> {
        UpdateConfig {
            payload,
            app_name: "Neuralese",
            app_version: "1.0.8",
            game_exe_name: "Neuralese.exe",
            updater_dir,
            wait_timeout: Duration::from_millis(5),
            health_timeout: Duration::from_millis(5),
            failure_point: None,
        }
    }

    fn runtime() -> FakeRuntime {
        FakeRuntime {
            available_space: u64::MAX,
            ..FakeRuntime::default()
        }
    }

    #[test]
    fn rejects_unmarked_installation() {
        let temp = TempDir::new().expect("temp");
        let install = make_install(temp.path(), false);
        let payload = payload(&[("Neuralese.exe", NEW_EXE)]);
        let mut runtime = runtime();

        let error = run_silent_update_with_runtime(
            options(&install),
            config(&payload, temp.path()),
            &mut runtime,
        )
        .expect_err("unmarked install must fail");

        assert!(error.contains("marker"));
        assert_eq!(fs::read(install.join("Neuralese.exe")).unwrap(), OLD_EXE);
    }

    #[test]
    fn process_wait_timeout_does_not_modify_installation() {
        let temp = TempDir::new().expect("temp");
        let install = make_install(temp.path(), true);
        let payload = payload(&[("Neuralese.exe", NEW_EXE)]);
        let mut runtime = runtime();
        runtime.wait_error = Some("process wait timeout".into());

        let result = run_silent_update_with_runtime(
            options(&install),
            config(&payload, temp.path()),
            &mut runtime,
        );

        assert!(result.is_err());
        assert_single_old_install(temp.path(), &install);
    }

    #[test]
    fn insufficient_space_does_not_stage_payload() {
        let temp = TempDir::new().expect("temp");
        let install = make_install(temp.path(), true);
        let payload = payload(&[("Neuralese.exe", NEW_EXE)]);
        let mut runtime = runtime();
        runtime.available_space = 1;

        let error = run_silent_update_with_runtime(
            options(&install),
            config(&payload, temp.path()),
            &mut runtime,
        )
        .expect_err("space check");

        assert!(error.contains("space"));
        assert_single_old_install(temp.path(), &install);
        assert_eq!(runtime.launches, vec![install.join("Neuralese.exe")]);
    }

    #[test]
    fn rejects_zip_slip_entries() {
        let temp = TempDir::new().expect("temp");
        let stage = temp.path().join("stage");
        let payload = payload(&[("../escape.exe", b"escape")]);

        let error =
            stage_payload(&payload, &stage, "Neuralese.exe").expect_err("zip slip must fail");

        assert!(error.contains("Unsafe zip path"));
        assert!(!temp.path().join("escape.exe").exists());
    }

    #[test]
    fn lock_contention_keeps_old_installation() {
        let temp = TempDir::new().expect("temp");
        let install = make_install(temp.path(), true);
        let payload = payload(&[("Neuralese.exe", NEW_EXE)]);
        fs::write(update_lock_path(&install), "777").expect("lock");
        let mut runtime = runtime();
        runtime.process_running = true;

        let result = run_silent_update_with_runtime(
            options(&install),
            config(&payload, temp.path()),
            &mut runtime,
        );

        assert!(result.expect_err("live lock").contains("already running"));
        assert_single_old_install(temp.path(), &install);
    }

    #[test]
    fn stale_lock_is_replaced() {
        let temp = TempDir::new().expect("temp");
        let install = make_install(temp.path(), true);
        let payload = payload(&[("Neuralese.exe", NEW_EXE)]);
        fs::write(update_lock_path(&install), "777").expect("lock");
        let mut runtime = runtime();

        run_silent_update_with_runtime(
            options(&install),
            config(&payload, temp.path()),
            &mut runtime,
        )
        .expect("stale lock update");

        assert_eq!(fs::read(install.join("Neuralese.exe")).unwrap(), NEW_EXE);
        assert!(!update_lock_path(&install).exists());
    }

    #[test]
    fn success_swaps_installation_after_health_acknowledgement() {
        let temp = TempDir::new().expect("temp");
        let install = make_install(temp.path(), true);
        fs::write(
            install.join(MANIFEST_FILE),
            r#"{"app_version":"1.0.7","install_dir":"C:\\Neuralese"}"#,
        )
        .expect("old install manifest");
        let payload = payload(&[("Neuralese.exe", NEW_EXE)]);
        let mut runtime = runtime();

        run_silent_update_with_runtime(
            options(&install),
            config(&payload, temp.path()),
            &mut runtime,
        )
        .expect("successful update");

        assert_eq!(fs::read(install.join("Neuralese.exe")).unwrap(), NEW_EXE);
        let manifest: serde_json::Value = serde_json::from_slice(
            &fs::read(install.join(MANIFEST_FILE)).expect("updated install manifest"),
        )
        .expect("valid install manifest");
        assert_eq!(manifest["app_version"], "1.0.8");
        assert_eq!(manifest["install_dir"], "C:\\Neuralese");
        assert_eq!(runtime.launches.len(), 1);
        assert_eq!(count_named_dirs(temp.path(), ".neuralese-backup-"), 0);
    }

    #[test]
    fn faults_restore_exactly_one_old_installation() {
        for point in [
            FailurePoint::AfterStaging,
            FailurePoint::AfterBackupRename,
            FailurePoint::AfterInstallRename,
        ] {
            let temp = TempDir::new().expect("temp");
            let install = make_install(temp.path(), true);
            let payload = payload(&[("Neuralese.exe", NEW_EXE)]);
            let mut config = config(&payload, temp.path());
            config.failure_point = Some(point);
            let mut runtime = runtime();

            assert!(
                run_silent_update_with_runtime(options(&install), config, &mut runtime,).is_err()
            );

            assert_single_old_install(temp.path(), &install);
        }
    }

    #[test]
    fn launch_failure_rolls_back() {
        let temp = TempDir::new().expect("temp");
        let install = make_install(temp.path(), true);
        let payload = payload(&[("Neuralese.exe", NEW_EXE)]);
        let mut runtime = runtime();
        runtime.launch_error = Some("launch failed".into());

        assert!(run_silent_update_with_runtime(
            options(&install),
            config(&payload, temp.path()),
            &mut runtime,
        )
        .is_err());

        assert_single_old_install(temp.path(), &install);
    }

    #[test]
    fn health_timeout_terminates_new_process_and_rolls_back() {
        let temp = TempDir::new().expect("temp");
        let install = make_install(temp.path(), true);
        let payload = payload(&[("Neuralese.exe", NEW_EXE)]);
        let mut runtime = runtime();
        runtime.health_error = Some("health timeout".into());

        assert!(run_silent_update_with_runtime(
            options(&install),
            config(&payload, temp.path()),
            &mut runtime,
        )
        .is_err());

        assert_eq!(runtime.terminated, 1);
        assert_single_old_install(temp.path(), &install);
    }

    #[test]
    fn health_marker_requires_exact_token_version_and_pid() {
        let temp = TempDir::new().expect("temp");
        let marker = temp.path().join("health.json");
        fs::write(
            &marker,
            r#"{"token":"correct","version":"1.0.8","pid":4242}"#,
        )
        .unwrap();

        assert!(validate_health_marker(&marker, "correct", "1.0.8", 4242).is_ok());
        assert!(validate_health_marker(&marker, "stale", "1.0.8", 4242).is_err());
        assert!(validate_health_marker(&marker, "correct", "1.0.7", 4242).is_err());
        assert!(validate_health_marker(&marker, "correct", "1.0.8", 7).is_err());
    }

    #[test]
    fn rollback_is_idempotent() {
        let temp = TempDir::new().expect("temp");
        let install = temp.path().join("Neuralese");
        let backup = temp.path().join("backup");
        fs::create_dir_all(&install).unwrap();
        fs::write(install.join("Neuralese.exe"), NEW_EXE).unwrap();
        fs::create_dir_all(&backup).unwrap();
        fs::write(backup.join("Neuralese.exe"), OLD_EXE).unwrap();

        rollback_installation(&install, &backup).expect("first rollback");
        rollback_installation(&install, &backup).expect("second rollback");

        assert_eq!(fs::read(install.join("Neuralese.exe")).unwrap(), OLD_EXE);
        assert!(!backup.exists());
    }

    fn assert_single_old_install(root: &Path, install: &Path) {
        assert_eq!(fs::read(install.join("Neuralese.exe")).unwrap(), OLD_EXE);
        assert_eq!(count_files_with_contents(root, OLD_EXE), 1);
    }

    fn count_files_with_contents(root: &Path, contents: &[u8]) -> usize {
        fs::read_dir(root)
            .into_iter()
            .flatten()
            .flatten()
            .map(|entry| entry.path())
            .map(|path| {
                if path.is_dir() {
                    count_files_with_contents(&path, contents)
                } else {
                    usize::from(fs::read(path).ok().as_deref() == Some(contents))
                }
            })
            .sum()
    }

    fn count_named_dirs(root: &Path, prefix: &str) -> usize {
        fs::read_dir(root)
            .into_iter()
            .flatten()
            .flatten()
            .filter(|entry| {
                entry.path().is_dir() && entry.file_name().to_string_lossy().starts_with(prefix)
            })
            .count()
    }
}
